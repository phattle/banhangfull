﻿
    $(document).ready(function (e) {
        //$(".search-field").keyup(function ()

   
        //$(document).delegate(".search-field", "keyup", function () {
        //    search = $(".search-field").val();
        //    cat = $("#category").val();

        //    //if (cat == 'undefined' || cat == "Categories" ||cat == null || cat=="") {
        //    //    cat =null;
        //    //}
        
        //    $.ajax({
        //        type:"post",
        //        url: "/Home/Search",
        //        data: { keywork: search, cat:cat },
        //        success: function (res) {
        //            //$(".homebanner-holder").html("");
        //            $(".homebanner-holder").html(res).replaceAll();
        //        }
        //    });
        //    return false;

        //});



    });




