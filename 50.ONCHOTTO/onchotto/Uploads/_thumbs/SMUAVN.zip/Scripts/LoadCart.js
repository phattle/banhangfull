﻿
$(document).ready(function () {
    //$("#cart-item").click(function () {
        $("#cart-item").load("/Cart/PartialCart");
    //});
           

});
